package jdbcprojectsql;

	import java.sql.*;

	public class test 
	{
		public static void main(String args[])
		{
			try
				{ 
				Class.forName("com.mysql.jdbc.Driver");  
				Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/fed","root","root");  
				Statement s=c.createStatement();  
				
				String sql = "create table cust_details " +
		                   "(id INTEGER not NULL, " +
		                   " name VARCHAR(50), " + 
		                   " PRIMARY KEY ( id ))"; 
				s.executeUpdate(sql);
				System.out.println("Table created successfully");
				c.close();  

				}
			catch(Exception e)
				{
					System.out.println(e);
				}  
		}
	}
