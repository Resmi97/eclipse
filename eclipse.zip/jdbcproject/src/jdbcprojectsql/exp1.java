package jdbcprojectsql;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class exp1 extends con1
{
	
	public static void main(String[] args) throws SQLException 
	{
		Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/students","root","root");
		Statement s=c.createStatement();
		
		Connection c1=DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","root");
		Statement s1=c1.createStatement();
		
		exp1 obj = new exp1();
		obj.create(c, s);
		obj.display(c1, s1);
	}
	}


class con1
	{
		String sql;
		void create(Connection c, Statement s) throws SQLException
		{
			sql = "create table stu1 (id int not null primary key, name varchar(50))";
			s.executeUpdate(sql);
			System.out.println("table Created .....");
		}	
		
		
		
		void display(Connection c1, Statement s1) throws SQLException
		{
			sql = "Select * from branch";
			ResultSet rs=s1.executeQuery(sql);
			while(rs.next())
				System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3));
			c1.close();
			System.out.println("task completed ....");
		}
		
		
}

