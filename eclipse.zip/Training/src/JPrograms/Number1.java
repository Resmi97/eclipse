package JPrograms;
import java.util.Scanner;

public class Number1 {

	public static void main(String[] args) {
		//Reverse a Number in Java

		int n,reverse=0,a,t;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number: ");
		n=sc.nextInt();

		while(n>0)
		{
			a=n%10;
			reverse=(reverse*10)+a;
			n=n/10;
		}
		System.out.println("Reverse: " +reverse);

			
	}

}
