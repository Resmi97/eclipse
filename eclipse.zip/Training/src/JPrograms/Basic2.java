package JPrograms;
import java.util.Scanner;

public class Basic2 {
	//Prime Number Program in Java
	public static void main(String[] args) {
	int n=4,flag=0,i;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter a number: ");
	n=sc.nextInt();

	for(i=2;i<=(n/2);++i)
	{
		if(n%i==0)
		{
			flag =1;
		}
		else
		{
			flag =0;
		}
	}
	
	if(n==1)
	{
		System.out.println("1 is neither prime nor composite");
	}
	else
	{
	if(flag==1)
		{
		System.out.println("The given number is not prime");
		}
	else
		{
		System.out.println("The given number is prime");
		}
	}
}
}
