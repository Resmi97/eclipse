package JPrograms;
import java.util.Scanner;
public class Basic4 {

	public static void main(String[] args) {
		// Factorial Program in Java
		int n,factorial=1,i;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter a number: ");
	n=sc.nextInt();
	for(i=1;i<=n;i++)
	{
		factorial=factorial*i;
	}
	System.out.println("Factorial of " +n +" is " +factorial);

	}

}
