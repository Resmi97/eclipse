package JPrograms;

import java.util.Scanner;

public class String11 {
	// Java Program to replace lower-case characters with upper-case and vice-versa

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string: ");
		String s=sc.next();
		System.out.println(s.toUpperCase()); 
		System.out.println(s.toLowerCase()); 
		
	}

}
