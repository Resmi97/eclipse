package JPrograms;

import java.util.Scanner;

public class String16 {
	// Java Program to find Reverse of the string

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string to reverse: ");
		String s=sc.next();
		for(int i=s.length()-1;i>=0;i--)
		{
		System.out.print(s.charAt(i));
		}
		
	}

}
