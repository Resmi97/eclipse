package JPrograms;
import java.util.Scanner;

public class Basic5 {

	public static void main(String[] args) {
		//Armstrong Number in Java
		int n,a,sum=0,t;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number: ");
		n=sc.nextInt();
		t=n;
		while(n>0)
		{
		a=n%10;
		sum=sum+(a*a*a);
		n=n/10;
		}
	if(sum==t)
	{
		System.out.println("The given number is an armstrong number");
	}
	else
		System.out.println("The given number is not an armstrong number");

	}

}
