package JPrograms;

public class String3 {
	
	//Java Program to count the total number of punctuation characters exists in a String

	public static void main(String[] args) {

		 int p = 0;  
			
	       String str = "Hello! Hi! Welcome!";  
	        for (int i = 0; i < str.length(); i++) {  
	            if(str.charAt(i) == '!' ) {  
	                p++;  
	            }  
	        }  
	     System.out.println("Total number of punctuation characters exists in string: " +  p); 
	}
	}

