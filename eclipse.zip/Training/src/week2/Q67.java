package week2;

public class Q67 {

	public static void main(String[] args) {
		//string lenth
		String txt = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		System.out.println("The length of the txt string is: " + txt.length());
	}

}
