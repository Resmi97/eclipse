package week2;

public class Stude {
	int id=7;
	String name="Name";
	int age;
	String place;

}
