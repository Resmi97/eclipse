package week2;

class Q96{  
	  static int cube(int x){  
	  return x*x*x;  
	  }  
	  
	  public static void main(String args[]){  
	  int result=Q96.cube(5);  
	  System.out.println(result);  
	  }  
	}  
