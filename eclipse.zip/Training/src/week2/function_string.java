package week2;
import java.lang.*;
import java.util.Scanner;

public class function_string {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	String a,b;
	char o;
	System.out.println("Enter the first string: ");
	a=sc.next();
	System.out.println("Enter the second string: ");
	b=sc.next();
	System.out.println("Enter an option: ");
	System.out.println("A.Concat");
	System.out.println("B.Length");
	System.out.println("C.Lower Case");
	System.out.println("D.Upper Case");
	System.out.println("E.Reverse");

	o=sc.next().charAt(0);
	

	switch(o)
	{    
	case 'A':   
		System.out.println("Concatination : " +conFunction(a,b));
	break; 
	case 'B':
		System.out.println("Length of " +a +": " +lenFunction(a));
		System.out.println("Length of " +b +": " +lenFunction(b));
		break;
	case 'C':
		System.out.println(a +"to lower case: " +lowFunction(a));
		System.out.println(b +"to lower case: " +lowFunction(b));
		break;
	case 'D':
		System.out.println(a +"to upper case: " +uppFunction(a));
		System.out.println(b +"to upper case: " +uppFunction(b));
		break;
	case 'E':
		System.out.println("Reverse of " +a +": " +revFunction(a));
		System.out.println("Reverse of " +b +": " +revFunction(b));
		break;
	}
	}
	public static String conFunction(String n1,String n2)
	{
			
		String s1;
		s1=n1.concat(n2);
	return s1;
	}
	public static int lenFunction(String n1)
	{
			
		int s2;
		s2=n1.length();
	return s2;
	}
	public static String lowFunction(String n1)
	{
			String s3;
		s3=n1.toLowerCase();
	return s3;
	}
	public static String uppFunction(String n1)
	{
			String s4;
		s4=n1.toUpperCase();
	return s4;
	}
   public static StringBuilder revFunction(String n1)
	{
			  StringBuilder b=new StringBuilder(n1);
			  StringBuilder s5=b.reverse();  

	return s5;
	}

}
