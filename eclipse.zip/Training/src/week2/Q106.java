package week2;
class Student1234{  
int rollno;  
String name,course;  
float fee;  
Student1234(int rollno,String name,String course){  
this.rollno=rollno;  
this.name=name;  
this.course=course;  
}  
Student1234(int rollno,String name,String course,float fee){  
this.fee=fee;  
//this(rollno,name,course);//C.T.Error  
}  
void display(){System.out.println(rollno+" "+name+" "+course+" "+fee);}  
}  
class Q106{  
public static void main(String args[]){  
	Student1234 s1=new Student1234(111,"ankit","java");  
	Student1234 s2=new Student1234(112,"sumit","java",6000f);  
s1.display();  
s2.display();  
}}  
