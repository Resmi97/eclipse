/*package week2;
//multiple inheritance (not supported by java - compile time error)
class A2{  
void msg(){System.out.println("Hello");}  
}  
class B2{  
void msg(){System.out.println("Welcome");}  
}  
class C1 extends A2,B2{//suppose if it were  
   
 public static void main(String args[]){  
   C1 obj=new C1();  
   obj.msg();//Now which msg() method would be invoked?  
}  
}  */
