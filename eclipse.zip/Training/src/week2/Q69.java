package week2;

public class Q69 {

	public static void main(String[] args) {
		//locate
		String txt = "Please locate where 'locate' occurs!";
		System.out.println(txt.indexOf("locate")); // Outputs 7

	}

}
