package week2;

public class Q68 {

	public static void main(String[] args) {
		//toUpperCase and lowercase
		String txt = "Hello World";
		System.out.println(txt.toUpperCase());   // Outputs "HELLO WORLD"
		System.out.println(txt.toLowerCase());   // Outputs "hello world"
	}

}
