package week2;

public class Q71 {

	public static void main(String[] args) {
		int a=7,b=8,c;
		c=minFunction(a,b);
		System.out.println("Minimum value:"+c);
		c=addFunction(a,b);
		System.out.println("Addition:"+c);
		c=subFunction(a,b);
		System.out.println("Difference:"+c);
		c=divFunction(a,b);
		System.out.println("Division:"+c);
		c=modFunction(a,b);
		System.out.println("Remainder:"+c);
	}
	public static int minFunction(int n1,int n2)
	{
		int min;
		if(n1>n2)

			min=n2;
		else
			min=n1;
	return min;
	}
	public static int addFunction(int n1,int n2)
	{
		int add;
		add=n1+n2;
	return add;
	}
	public static int subFunction(int n1,int n2)
	{
		int sub;
		if(n1>n2)
			sub=n1-n2;
		else
			sub=n2-n1;
	return sub;
	}
	public static int mulFunction(int n1,int n2)
	{
		int mul;
		mul=n1*n2;
	return mul;
	}
	public static int divFunction(int n1,int n2)
	{
		int div;
		if(n1>n2)
			div=n1/n2;
		else
			div=n2/n1;
	return div;
	}
	public static int modFunction(int n1,int n2)
	{
		int mod;
		if(n1>n2)
			mod=n1%n2;
		else
			mod=n2%n1;
	return mod;
	}

}
