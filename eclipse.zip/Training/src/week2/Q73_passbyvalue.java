package week2;

public class Q73_passbyvalue {
		public static void main(String[] args) {
			 int n1=10,n2=2;
		 Method m=new Method();
		 m.add(2,3);
		
		}
			public  int add (int n1,int n2)
			{
				int add;
				add=n1+n2;
				System.out.println("Addition:"+add);

			return add;
			}
		
	}

