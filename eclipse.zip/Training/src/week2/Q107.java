package week2;
//this: to pass as an argument in the method
class Q107{  
  void m(Q107 obj){  
  System.out.println("method is invoked");  
  }  
  void p(){  
  m(this);  
  }  
  public static void main(String args[]){  
	  Q107 s1 = new Q107();  
  s1.p();  
  }  
}  
