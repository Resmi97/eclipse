package week2;

//Java Program to demonstrate the use of static variable  
class Q92{  
 int rollno;//instance variable  
 String name;  
 static String college ="ITS";//static variable  
 //constructor  
 Q92(int r, String n){  
 rollno = r;  
 name = n;  
 }  
 //method to display the values  
 void display (){System.out.println(rollno+" "+name+" "+college);}  

//Test class to show the values of objects  
//public class TestStaticVariable1{  
public static void main(String args[]){  
	Q92 s1 = new Q92(111,"Karan");  
	Q92 s2 = new Q92(222,"Aryan");  
//we can change the college of all objects by the single line of code  
//Student.college="BBDIT";  
s1.display();  
s2.display();  
}  
}  
