package week2;

public class Q66 {

	public static void main(String[] args) {
		//string format
		/*System.out.printf("The value of the float variable is " +
                "%f, while the value of the integer " +
                "variable is %d, and the string " +
                "is %s", floatVar, intVar, stringVar);*/
		
		float floatVar=10;
		int intVar=5;
		String stringVar=(String) "hey";
		String fs;

		fs = String.format("The value of the float variable is " +
                "%f, while the value of the integer " +
                "variable is %d, and the string " +
                "is %s", floatVar, intVar, stringVar);
System.out.println(fs);

	}

}
