package week2;

public class Q70_multidimensional {

	public static void main(String[] args) {
		
		int[][] myNumbers = { {1, 2, 3, 4}, {5, 6, 7} };
		int x = myNumbers[0][2];
		System.out.println(x); 

	}

}
