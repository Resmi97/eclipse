package week2;
import java.util.Scanner;

public class Implementation {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int i,arr[],sum=0,a,avg;
	char g;
	arr=new int[20];
	System.out.println("Enter your name: ");
	String name=sc.next();
	System.out.println("Enter your marks: ");

	for(i=1;i<=6;i++)
	{
		
          arr[i] = sc.nextInt();
          sum=sum+arr[i];
	}
	avg=sum/6;
	
	if(avg>=80)
	{
		g = 'A';
	}
	else if(avg>=70&&avg<80)
	{
		g = 'B';
	}
	else if(avg>=60&&avg<70)
	{
		g = 'C';
	}
	else if(avg>=50&&avg<60)
	{
		g = 'C';
	}
	else
	{	
		g = 'F';
	
	}
	System.out.println("************************");
	
	System.out.println("Grade Card");
	System.out.println("------------------------");
	System.out.println("Name: " +name);
	System.out.println("Grade: " +g);
	System.out.println("Total Mark out of 600: " +avg);
	


	if(g=='F')
	{
		System.out.println("Result: Failed");
	}
	else
	{
		System.out.println("Result: Passed");
	}
	System.out.println("************************");

	}

}
