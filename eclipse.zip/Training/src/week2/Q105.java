package week2;

class Student123{  
int rollno;  
String name,course;  
float fee;  
Student123(int rollno,String name,String course){  
this.rollno=rollno;  
this.name=name;  
this.course=course;  
}  
Student123(int rollno,String name,String course,float fee){  
this(rollno,name,course);//reusing constructor  
this.fee=fee;  
}  
void display(){System.out.println(rollno+" "+name+" "+course+" "+fee);}  
}  
class Q105{  
public static void main(String args[]){  
	Student123 s1=new Student123(111,"ankit","java");  
	Student123 s2=new Student123(112,"sumit","java",6000f);  
s1.display();  
s2.display();  
}}  
