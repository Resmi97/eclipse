package week2;


public class Q75_methodoverloading {

	public static void main(String[] args) {
		int a=3,b=8,c=10;
		int d;
		char o;
	
		c=addFunction(a,b);
		d=addFunction(a,b);


		}
			public static int addFunction (int n1,int n2)
			
			{
				int add;
				add=n1+n2;
				System.out.println("Addition:"+add);

			return add;
			}
		
			public static int addFunction (int n1,int n2,int n3)
			{
				int add;
				add=n1+n2+n3;
				System.out.println("Addition:"+add);

			return add;
			}
}
