package week2;

 class Q76 {
		public static void main(String[] args) {
	  
	    Test obj = new Test();
	    //obj.a = 30;
	    System.out.println("Value of a : " + obj.a);
	    System.out.println("Value of b : " + obj.b);
	    obj.Test_method();
	  }
}
 class Test {
	 int a,b,c; 
	 Test() {
	    a=15;b=20;
	    
	  }
	 
	  void Test_method() {
		 c=a+b;
	    System.out.println("Addition: " + c );
	  }
	}
 
