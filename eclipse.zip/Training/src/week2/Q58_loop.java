package week2;

public class Q58_loop {

	public static void main(String[] args) {
		//Using no condition in for loop  
	    for(;;){  
	        System.out.println("infinitive loop");  
	    }  

	}

}
