package week2;

class Rectangle {
	 int a,b,c; 
	 Rectangle() {
	    a=15;b=20;
	    
	  }
	 
	  void Rectangle_method() {
		 c=a*b;
	    System.out.println("Area: " + c );
	  }
	}