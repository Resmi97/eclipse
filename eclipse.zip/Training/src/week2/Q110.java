package week2;

class Q110{  
void m(){  
System.out.println(this);//prints same reference ID  
}  
public static void main(String args[]){  
	Q110 obj=new Q110();  
System.out.println(obj);//prints the reference ID  
obj.m();  
}  
}  
