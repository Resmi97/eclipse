package week2;

public class Q74_void {

	  static void myMethod() {
	    System.out.println("Hello!");

	  }

	  public static void main(String[] args) {
	    myMethod();
	  }
	}