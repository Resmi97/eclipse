package week2;

public class Area {

	public static void main(String[] args) {
		Rectangle obj = new Rectangle();
		System.out.println("Value of a : " + obj.a);
	    System.out.println("Value of b : " + obj.b);
	    obj.Rectangle_method();
	 }
	}
	