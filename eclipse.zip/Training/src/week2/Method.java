package week2;

	public class Method {
		
		public static void main(String[] args) {
			 int n1=10,n2=2;
		 Method m=new Method();
		 m.add(n1,n2);
		 m.sub(n1,n2);
		 m.mul(n1,n2);
		 m.div(n1,n2);
		 m.mod(n1,n2);
		}
			public  int add (int n1,int n2)
			{
				int add;
				add=n1+n2;
				System.out.println("Addition:"+add);

			return add;
			}
			public  int sub (int n1,int n2)
			{
				int sub;
				if(n1>n2)
					sub=n1-n2;
				else
					sub=n2-n1;
				System.out.println("Difference:"+sub);

			return sub;
			}
			public  int mul (int n1,int n2)
			{
				int mul;
				mul=n1*n2;
				System.out.println("Product:"+mul);

			return mul;
			}
			public  int div (int n1,int n2)
			{
				int div;
				if(n1>n2)
					div=n1/n2;
				else
					div=n2/n1;
				System.out.println("Division:"+div);

			return div;
			}
			public  int mod (int n1,int n2)
			{
				int mod;
				if(n1>n2)
					mod=n1%n2;
				else
					mod=n2%n1;
				System.out.println("Modulus:"+mod);

			return mod;
			}

	}


		
		 
