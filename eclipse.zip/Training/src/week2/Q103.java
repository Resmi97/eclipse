package week2;
//Calling default constructor from parameterized constructor:
class A1{  
A1(){System.out.println("hello a");}  
A1(int x){  
this();  
System.out.println(x);  
}  
}  
class Q103{  
public static void main(String args[]){  
A1 a=new A1(10);  
}}  
