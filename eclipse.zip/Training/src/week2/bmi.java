package week2;

import java.util.Scanner;
public class bmi {

	public static void main(String[] args) {
	      Scanner sc = new Scanner(System.in);
	    
	     //Age
	     	System.out.println("Enter Age: ");
		    int a = sc.nextInt();
		System.out.println("Age : " +a);

	     //Height
	     	System.out.println("Enter Height in m:  ");
	     	double h = sc.nextDouble();
		System.out.println("Height : " +h);

	    //Weight
	     	System.out.println("Enter Weight in kg:  ");
	     	double w= sc.nextDouble();
	     System.out.println("Weight : " +w);
	     
	   //Gender
	      	System.out.println("Enter Gender (F/M): ");
	        char G = sc.next().charAt(0);
	     System.out.println("Gender : " +G);
	     
	     if(G=='M')
	     {
	    	 
	     }
	     else if(G=='F')
	     {
	    	 
	     }
	     else
	     {
		     System.out.println("Please enter a correct input for Gender (F/M): ");

	     }
	    
	     //bmi
	     double bmi = (w/ (h*h));
	     System.out.println("BMI : " +bmi);
	     String text;
	     
	   /*  switch (bmi) {
	       if (bmi < 18) {
	         text = "Underweight";
	       }
	       else if { 
	    	   ((bmi> 18) && (bmi < 25))}
	         text = "Normal";
	         else if {((bmi > 25) && (bmi < 30)):
		     text = "Overweight";
		     break;
	       case (bmi > 30):
		     text = "Obesity";
		     break;
	       default:
	         text = "No value found";
	     } */
	}
}
