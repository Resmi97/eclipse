package week2;
class Q98{  
	  static{  
	  System.out.println("static block is invoked");  
	  System.exit(0);  
	  }  
	}  
