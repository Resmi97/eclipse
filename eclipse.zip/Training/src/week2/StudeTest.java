package week2;

public class StudeTest {

	public static void main(String[] args) {
		Stude s1=new Stude();
		System.out.println(s1.id);
		System.out.println(s1.name);

		  //Initializing objects  
		  s1.age=30;  
		  s1.place="Kerala"; 
		System.out.println(s1.age);
		System.out.println(s1.place);
		 


	}

}
