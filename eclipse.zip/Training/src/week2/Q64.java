package week2;

public class Q64 {

	public static void main(String[] args) {
		//string length
		 String palindrome = "J a v a Tutorials";
	      int len = palindrome.length();
	      System.out.println( "String Length is : " + len );

	}

}
