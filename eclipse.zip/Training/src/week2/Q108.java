package week2;
//this: to pass as argument in the constructor call
class B{  
	Q108 obj;  
  B(Q108 obj){  
    this.obj=obj;  
  }  
  void display(){  
    System.out.println(obj.data);//using data member of A4 class  
  }  
}  
  
class Q108{  
  int data=10;  
  Q108(){  
   B b=new B(this);  
   b.display();  
  }  
  public static void main(String args[]){  
	  Q108 a=new Q108();  
  }  
}  
