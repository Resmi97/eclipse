package week2;

public class Q63 {

	public static void main(String[] args) {
		//string
		  char[] helloArray = { 'h', 'e', 'l', 'l', 'o', '.' };
	      String helloString = new String(helloArray);  
	      System.out.println( helloString );

	}

}
