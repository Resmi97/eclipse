package week2;
//Example of this keyword that you return as a statement from the method
class Z{  
Z getZ(){  
return this;  
}  
void msg(){System.out.println("Hello java");}  
}  
class Q109{  
public static void main(String args[]){  
new Z().getZ().msg();  
}  
}  
