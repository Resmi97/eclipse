package week2;

class Employee{  
	 float salary=40000;  
	}  
	class Q111 extends Employee{  
	 int bonus=10000;  
	 public static void main(String args[]){  
Q111 p=new Q111();  
	   System.out.println("Programmer salary is:"+p.salary);  
	   System.out.println("Bonus of Programmer is:"+p.bonus);  
	}  
	}  
	 
