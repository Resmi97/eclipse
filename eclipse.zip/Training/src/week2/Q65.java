package week2;

public class Q65 {

	public static void main(String[] args) {
		//concat string
		 String string1 = "saw I was ";
	      System.out.println("Dot " + string1 + "Tod");

	}

}
