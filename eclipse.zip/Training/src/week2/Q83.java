package week2;



//	example of an anonymous object in Java.
	 
	class Q83{  
	 void fact(int  n){  
	  int fact=1;  
	  for(int i=1;i<=n;i++){  
	   fact=fact*i;  
	  }  
	 System.out.println("factorial is "+fact);  
	}  
	public static void main(String args[]){  
	 new Q83().fact(5);//calling method with anonymous object  
	}  
	} 
