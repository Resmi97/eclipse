package week2;

import java.util.Scanner;

public class pattern {

	public static void main(String[] args) {
		//5*5 pattern program
				int i,j,n=5;
				Scanner sc =new Scanner(System.in);
				//System.out.println("Enter the symbol:");
				//char s= sc.next().charAt(0);
				//System.out.println( s);
				
				for(i=1;i<=n;i++)
				{
					System.out.print("*");

					for(j=1;j<n;j++)
					{
						System.out.print("*");
					}
					System.out.println();

				}

	}

}
