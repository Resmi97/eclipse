package week2;

public class Q55_loop {

	public static void main(String[] args) {
		 //Declaring an array  
	    int arr[]={12,23,44,56,78};  
	    //Printing array using for-each loop  
	    for(int i:arr){  
	        System.out.println(i);  
	    }  

	}

}
