package week2;

public class Q77 {

	static int height = 5;
	  
	static int width = (2 * height) - 1;
	
	static int abs(int d)
	{
	    return d < 0 ? -1 * d : d;
	}
	  
	// Function to print the pattern of 'I'
	static void printI()
	{
	    int i, j;
	    for (i = 0; i < height; i++) 
	    {
	        for (j = 0; j < height; j++)
	        {
	            if (i == 0 || i == height - 1)
	                System.out.printf("*");
	            else if (j == height / 2)
	                System.out.printf("*");
	            else
	                System.out.printf(" ");
	        }
	        System.out.printf("\n");
	    }
	}
	public static void main(String[] args)
	{
	    printI();
	}
	}