package hr1;

public class HRManagement2 {
	int id;
	String name;  
	double amount=6000;
	int leave;
	double bonus=5000;
void insert(int a,String n,int l){  
		id=a;  
		name=n;  
		leave=l;
		System.out.println("ID:" +id); 
		System.out.println("Name:" +name); 
		System.out.println("Leave:" +leave); 
		}  

void salary(){
		if(leave>5)
		{
		double amt=amount-(leave*100);
		System.out.println("Salary:" +amt);  

		}
		else
		{
		double amt=amount+bonus;
		System.out.println("Salary:" +amt);  
		} 
	}}