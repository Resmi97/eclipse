package hr1;


public class HRManagement1 {

		public static void main(String[] args){ 
			HRManagement2 b1=new HRManagement2();  


			b1.insert(179,"Resmi",1); 
			b1.salary(); 

			}
	}

