package hr1;
import java.util.Scanner;

public class TAgency {
	int number;
	String name;
	int mod;
	int amount;
	int place;
	
void insert(){  
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your name: " ); 
		String name=sc.next();
		System.out.println("Enter the number of persons: " ); 
		int number=sc.nextInt();
		System.out.println("Enter the destination(1-Trivandrum ,2-Kochi): " ); 
		int place=sc.nextInt();
		System.out.println("Enter the mode(1-Road ,2-Railways ,3-Airways): " ); 
		int mod=sc.nextInt();
		
		System.out.println("Number of persons : " +number); 
		System.out.println("Name: " +name); 
		//mode
		if(mod==1)
			{
				System.out.println("Mode of Transportation: Road ");
			}
		else if(mod==2)
		   {
				System.out.println("Mode of Transportation: Railways ");
		   }
		else
			{
				System.out.println("Mode of Transportation: Airways ");
			}
		//place
		if(place==1)
			{
				System.out.println("Destination: Trivandrum"); 
		
			}
		else if(place==2)
			{
				System.out.println("Destination: Kochi"); 
			}
		else
			{
				System.out.println("Invalid destination"); 
			}
		
//Amount
	if(place==1)
		{
			if(mod==1)
				{
					amount=number*500;
					System.out.println("Amount: " +amount);

				}
			else if(mod==2)
				{
					amount=number*1000;
					System.out.println("Amount: " +amount);

				}
			else if(mod==3)
				{
					amount=number*2000;
					System.out.println("Amount: " +amount);

				}
			else
				{
					System.out.println("Invalid mode");
		
				}
		}
	else if(place==2)
		{
			if(mod==1)
				{
					amount=number*1000;
					System.out.println("Amount: " +amount);

				}
			else if(mod==2)
				{
					amount=number*2000;
					System.out.println("Amount: " +amount);

				}
			else if(mod==3)
				{
					amount=number*3000;
					System.out.println("Amount: " +amount);

				}
			else
				{
					System.out.println("Invalid mode");
				}

		}
	}
}


	

	
	


