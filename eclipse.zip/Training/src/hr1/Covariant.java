package hr1;
class A11  
{  
	A11 foo()  
    {  
        return this;  
    }  
      
    void print()  
    {  
        System.out.println("Inside the class A1");  
    }  
}  
  
  
// A2 is the child class of A1  
class A22 extends A11  
{  
    @Override  
    A22 foo()  
    {  
        return this;  
    }  
      
    void print()  
    {  
        System.out.println("Inside the class A2");  
    }  
}  
  
// A3 is the child class of A2  
class A33 extends A22  
{  
    @Override  
    A33 foo()  
    {  
        return this;  
    }  
      
    @Override  
    void print()  
    {  
        System.out.println("Inside the class A3");  
    }  
}  
  
public class Covariant
{  
    // main method  
    public static void main(String argvs[])  
    {  
       A11 a1 = new A11();  
         
       a1.foo().print();  
         
       A22 a2 = new A22();  
         
       a2.foo().print();  
         
       A33 a3 = new A33();  
         
       a3.foo().print();  
         
    }  
}  
