package hr1;

public class TravelAgency {

	public static void main(String[] args)
			{
	
			TAgency a1=new TAgency();  
			a1.insert(); 
			System.out.println("********");
			}
	}

