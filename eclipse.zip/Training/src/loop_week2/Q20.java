package loop_week2;

import java.util.Scanner;

public class Q20 {

	public static void main(String[] args) {
		// Reverse A String In Java 
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the string to reverse: ");
		String str=new  String();
		System.out.println("Enter the string to reverse: " +str);

	}

}
