package loop_week2;

public class Q1 {

	public static void main(String[] args) {
		//display a text 5 times
		 int i=1;  
		    while(i<=5){  
		        System.out.println("Hello World");  
		    i++;  
		    }  
	}

}

	
