package loop_week2;

import java.util.Scanner;

public class Q5 {

	public static void main(String[] args) {
		//Calculate Electricity Bill
		Scanner scanner = new Scanner(System.in);
	    System.out.println("Enter a units used:");
	    int n = scanner.nextInt();

	}

}
