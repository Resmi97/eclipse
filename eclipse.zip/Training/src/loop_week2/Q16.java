package loop_week2;

import java.util.Scanner;

public class Q16 {

	public static void main(String[] args) {
		//Addition Of Two Numbers
		int[] num=new int[2];
		int sum=0;
		Scanner scanner = new Scanner(System.in);
		for(int i=0;i<2;i++)
		{
	    System.out.println("Enter a number:");
	    num[i]=scanner.nextInt();
	    sum = sum + num[i];
		}
		 System.out.println("Sum : " + sum);

	}

}
