package loop_week2;

import java.util.Scanner;

public class Q10 {

	public static void main(String[] args) {
		//Power In Java
		int pow=1;
	    Scanner scanner = new Scanner(System.in);
	    System.out.println("Enter a number:");
	    int n = scanner.nextInt();
	    System.out.println("Enter a degree :");
	    int p = scanner.nextInt();
	  while(p!=0) {
	    	 pow=pow*n;
	    	 --p;
	  }
	    System.out.println("Power of given  number: " + pow);

	  
	   

	    

	}

}
