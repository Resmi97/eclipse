package loop_week2;

import java.util.Scanner;

public class Q13 {

	public static void main(String[] args) {
		//Calculate CGPA Java Program 
		 Scanner scanner = new Scanner(System.in);
		 
	     System.out.println("Enter number of subjects: ");
	 
	     int n=scanner.nextInt();
	 
	     double[] marks=new double[n];
	 
	     System.out.println("Enter marks: ");
	 
	     for(int i=0;i<n;i++)
	     {
	        marks[i]=scanner.nextInt();
	     }
	 
	     double cgpa=0.0f,sum=0.0f;
	 
	     sum= cgpaCalculation(marks);
	 
	     cgpa=sum/n;
	 
	     System.out.println("cgpa="+cgpa);
	 
	     System.out.println("percantage from cgpa="+cgpa*9.5);
	 
	  }
	 
	 static double  cgpaCalculation(double marks[])
	 {
	    double sum=0;
	 
	    double grade[]=new double[marks.length];
	 
	    for(int i=0;i<marks.length;i++)
	    {
	       grade[i]=(marks[i]/10) ;
	    }
	 
	    for(int i=0;i<marks.length;i++)
	    {
	       sum+=grade[i];
	    }
	 
	     return sum;
	   }

	}
