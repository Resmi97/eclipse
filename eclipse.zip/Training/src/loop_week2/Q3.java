package loop_week2;

import java.util.Scanner;

public class Q3 {

	public static void main(String[] args) {
		//Display Sum of n Natural Numbers
	    int i=0,sum=0;
	    Scanner scanner = new Scanner(System.in);
	    System.out.println("Enter the value of n:");
	    int n = scanner.nextInt();
	    for(i=0;i<=n;i++)
	    sum=sum+i;
	    System.out.println("Sum of " +n + " natural numbers :  " +sum);


	}

}
