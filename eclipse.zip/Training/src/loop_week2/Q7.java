package loop_week2;

import java.util.Scanner;

public class Q7 {

	public static void main(String[] args) {
		//Calculate Discount Of Product 
		double offer;
		double nc;
		Scanner scanner = new Scanner(System.in);
	    System.out.println("Enter the cost of the product:");
     	double c= scanner.nextDouble();
     	 System.out.println("Enter the % discount of the product:");
      	double d= scanner.nextDouble();
      	offer=(c*d)/100;
    	 System.out.println("Discount amount: " +offer);

      	nc= c- offer;
   	 System.out.println("New cost: " +nc);

     	

	}

}
