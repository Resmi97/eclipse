package loop_week2;
import java.util.Scanner;
public class Q43 {

	public static void main(String[] args) {
		//Square Star Pattern
		int i,j;
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the number:");
		int n=sc.nextInt();
		//System.out.println("Enter the symbol:");
		//char s= sc.next().charAt(0);
		
		//System.out.println("N:" +n);
		//System.out.println("N:" +s);
		for(i=1;i<=n;i++)
		{
			System.out.print("*");

			for(j=1;j<n;j++)
			{
				System.out.print("*");
			}
			System.out.println();

		}


	}

}
