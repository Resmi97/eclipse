package loop_week2;

import java.util.Scanner;

public class Q19 {

	public static void main(String[] args) {
		//Find Ncr & Npr
		int factorial=1,ft=1,fr=1,i,j,npr,ncr,t,k;
		Scanner scanner = new Scanner(System.in);
	    System.out.println("Enter the value of n:");
	    int n = scanner.nextInt();
	    for(i=1;i<=n;i++)
		{
			factorial=factorial*i;
		}
		
		System.out.println("Enter the value of r:");
	    int r = scanner.nextInt();
	    t=n-r;
	    for(j=1;j<=t;j++)
		{
			ft=ft*j;
		}
		npr=factorial/ft;
		
		System.out.println("nPr value : "  +npr);
		//nCr
		 for(k=1;k<=r;k++)
			{
				fr=fr*k;
			}
		 ncr=npr/fr;
		System.out.println("nCr value : "  +ncr);

	}

}
