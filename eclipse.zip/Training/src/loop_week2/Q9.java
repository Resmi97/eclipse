package loop_week2;

import java.util.Scanner;

public class Q9 {

	public static void main(String[] args) {
		//commission Percentage
		Scanner scanner = new Scanner(System.in);
		double c;
		  System.out.print("Enter amount:");
	 
	     	double a= scanner.nextDouble();
	 
		  System.out.print("Enter commissionPercentage:");
	 
	     	double p= scanner.nextDouble();
	 
		  c=(p/100)*a;  	   
	 
	      	  System.out.println("Commission amount="+c);
	}

}
