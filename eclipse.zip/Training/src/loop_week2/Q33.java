package loop_week2;

import java.util.Scanner;

public class Q33 {

	public static void main(String[] args) {
		//Prime Number
		int flag=0,i;
		Scanner scanner = new Scanner(System.in);
	    System.out.println("Enter the number to check:");
	    int n = scanner.nextInt();
		for(i=2;i<=(n/2);++i)
		{
			if(n%i==0)
			{
				flag =1;
			}
			else
			{
				flag = 0;
			}
		}
		
		if(n==1)
		{
			System.out.println("1 is neither prime nor composite");
		}
		else
		{
		if(flag==1)
			{
			System.out.println("The given number is not prime");
			}
		else
			{
			System.out.println("The given number is prime");
			}
		}
	}

}
