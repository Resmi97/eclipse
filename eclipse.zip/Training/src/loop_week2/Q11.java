package loop_week2;

public class Q11 {

	public static void main(String[] args) {
		//Deprecation Program


	}

}
