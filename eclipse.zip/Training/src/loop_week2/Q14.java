package loop_week2;

import java.util.Scanner;
import java.lang.Math;

public class Q14 {

	public static void main(String[] args) {
		//Compound Interest Java Program
		Scanner scanner = new Scanner(System.in);
         double c = 0.00f;
		  System.out.print("Enter principal amount:");
	      double p= scanner.nextDouble();
		  System.out.print("Enter Interest rate in %:");
	      double r= scanner.nextDouble();
		  System.out.print("Enter componding period:");
	      double n= scanner.nextDouble();
	  	   c = p*(Math.pow(1+ (r/100),n) - 1);
	 
	      	  System.out.println("Compount Interest : "+c);
	}

	}


