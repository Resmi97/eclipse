package loop_week2;

public class Q2 {

	public static void main(String[] args) {
		//display numbers from 1 to 5
		 int i=1;  
		    while(i<=5){  
		        System.out.println(i);  
		    i++;  
		    }  

	}

}
