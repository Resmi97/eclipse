package loop_week2;

import java.util.Scanner;

public class Q8 {

	public static void main(String[] args) {
		//Calculate Distance Between Two Points
		double d;
		Scanner scanner = new Scanner(System.in);
	    System.out.println("Enter the first point:");
     	double a= scanner.nextDouble();
     	 System.out.println("Enter the second point:");
      	double b= scanner.nextDouble();
      	if(a>b)
      	{
      		d=a-b;
        	 System.out.println("Distance between two points: " +d);

      	}
      	else
      	{
      		d=b-a;
       	 System.out.println("Distance between two points: " +d);
      	}
   
      		
	}

}
