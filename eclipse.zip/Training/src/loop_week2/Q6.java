package loop_week2;

import java.util.Scanner;

public class Q6 {

	public static void main(String[] args) {
		//Calculate Average Of N Numbers
		 double i=0,sum=0;
		 double avg;
		    Scanner scanner = new Scanner(System.in);
		    System.out.println("Enter the value of n:");
		    int n = scanner.nextInt();
		    for(i=0;i<=n;i++)
		    {
		    sum=sum+i;
		    }
		    avg=sum/n;
		    System.out.println("Average of " +n + "  numbers :  " +avg);

	}

}
