package loop_week2;

import java.util.Scanner;

public class Q34 {

	public static void main(String[] args) {
		//Sum Of A Digits Of Number
		int n=646,sum=0,a;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a number:");
		n=scanner.nextInt();
		
		while(n>0)
		{
			a=n%10;
			sum=sum+a;
			n=n/10;
		}
		System.out.println("Sum of digits : " +sum);

	}

}
