package loop_week2;

import java.util.Scanner;

public class Q4 {

	public static void main(String[] args) {
		//Factorial Program In Java
		int factorial=1,i;
		Scanner scanner = new Scanner(System.in);
	    System.out.println("Enter a number to find the factorial:");
	    int n = scanner.nextInt();
	    for(i=1;i<=n;i++)
		{
			factorial=factorial*i;
		}
		System.out.println("Factorial of " +n +" is " +factorial);


	}

}
