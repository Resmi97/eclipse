package loop_week2;

import java.util.Scanner;

public class Q17 {

	public static void main(String[] args) {
		//Sum Of N Numbers
		int n;
		int sum=0;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a number:");
		n=scanner.nextInt();
		//System.out.println("Enter last number:");
		//n=scanner.nextInt();
		for(int i=1;i<=n;i++)
		{
	    sum = sum + i;
		}
		 System.out.println("Sum : " + sum);
	}

}
