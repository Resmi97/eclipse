package loop_week2;

import java.util.Scanner;

public class Q12 {

	public static void main(String[] args) {
		//Calculate Batting Average
		Scanner scanner = new Scanner(System.in);
		 
	     System.out.println("Enter number of matches: ");
	 
	     int n=scanner.nextInt();
	 
	     int[] score=new int[n];
	 
	     System.out.println("Enter score in each match: ");
	 
	     for(int i=0;i<n;i++)
	     {
	        score[i]=scanner.nextInt();
	     }
	 
	     double average=0.0f,total=0.0f;
	 
	     for(int i=0;i<n;i++)
	     {
	        total = total + score[i];
	     }
	 
	     average=total/n;
	 
	     System.out.println("Batting Average : "+average);

	}

}
