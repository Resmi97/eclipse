package loop_week2;

import java.util.Scanner;

public class Q15 {

	public static void main(String[] args) {
		//Calculate Average Marks 
		Scanner scanner = new Scanner(System.in);
		 
	     System.out.println("Enter number of subjects: ");
	 
	     int n=scanner.nextInt();
	 
	     double[] marks=new double[n];
	 
	     System.out.println("Enter marks: ");
	 
	     for(int i=0;i<n;i++)
	     {
	        marks[i]=scanner.nextInt();
	     }
	 
	     double average=0.0f,sum=0.0f;
	 
	     for(int i=0;i<n;i++)
	     {
	    	 sum= sum + marks[i];
	     }
	 
	     
	     average=sum/n;
	 
	     System.out.println("Average marks : "+average);

	}

}
