
public class LogicalOperator31 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean a = true;
        boolean b = false;
        System.out.println("a && b = " + (a&&b));
        System.out.println("a || b = " + (a||b) );
System.out.println("!(a && b) = " + !(a && b));

	}

}
