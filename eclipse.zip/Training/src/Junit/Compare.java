package Junit;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


public class Compare {
	@Test
	void test() {
	String string1="Junit";
	String string2="Junit";
int a=1;
int b=1;
	
assertEquals(string1,string2);
}
}
