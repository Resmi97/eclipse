package Junit;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
 class AreaRectangle {
	public static double area(double l,double b)
	{
		double area;
		area=l*b;
		System.out.println();
		System.out.println("Area: "+area);
		return area;
	}

	@Test
	void test() {
		assertEquals(0,AreaRectangle.area(0, 0));
		
	}

}
