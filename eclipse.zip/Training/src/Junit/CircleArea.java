
package Junit;
	import static org.junit.jupiter.api.Assertions.*;

	import org.junit.jupiter.api.Test;
	public class CircleArea {

			public static double area(double r) {
				double area;
				area=3.14*r*r;
				System.out.println(" Area : " +area);
				return area;
			}
			@Test
			void test() {
			assertEquals(0,CircleArea.area(0));

		}

	}
