package Junit;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


public class SurfaceArea {



		public static double areacube(double s) {
			double area;
			area=6*s*s;
			System.out.println("Curved Surface Area of a cube: " +area);
			return area;
		}
		@Test
		void test() {
		assertEquals(0,SurfaceArea.areacube(0));

	}

}