package Junit;
import org.junit.Assert;
import org.junit.Test;

public class Sample2 {


	public static void swaptest(int p,int q) {
		
		int p1=0,q1=0,r=0;
		r=p1;
		p1=q1;
		q1=r;

	}
	 @Test
	    public void swaptest() {
	     
	       int a,b;
	       Assert.assertEquals(a=1,b=2);
	       Assert.assertEquals(a=3,b=4);

}

}