package Junit;

import org.junit.Assert;
import org.junit.Test;

public class Sample5 {

    public static int sum(int n) {
        return n + n;
    }

    @Test
    public void squareTest() {
        Assert.assertEquals(10, sum(5));
        Assert.assertEquals(8, sum(4));
        Assert.assertEquals(6, sum(3));
        Assert.assertEquals(4, sum(2));
        Assert.assertEquals(2, sum(1));
    }
}
