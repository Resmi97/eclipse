package Assignment1;

public class Q1_division {

	public static void main(String[] args) {
		
		int quo,rem,n1,n2;
		
		n1=11;n2 = 3;
		
		quo = n1/n2;
		rem = n1%n2;
		
		System.out.println("Input numbers:" + n1 + "," + n2);
		System.out.println("Quotient=" + quo);
		System.out.println("Reminder=" + rem);	

	}

}
