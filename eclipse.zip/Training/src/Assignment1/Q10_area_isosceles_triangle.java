package Assignment1;

public class Q10_area_isosceles_triangle {

	public static void main(String[] args) {
		double area,b=2,h=3;
		System.out.println("Base:" +b);
		System.out.println("Height:" +h);
		area=0.5*b*h;
		System.out.println("Area of the isosceles triangle:" +area);
	}

}
