package Assignment1;

public class Q17_perimeter_rectangle {

	public static void main(String[] args) {
		int p,l=2,b=4;
		System.out.println("Length:" +l);
		System.out.println("Breadth:" +b);
		p=(2*(l+b));
		System.out.println("Perimeter of the Rectangle:" +p);
	}

}
