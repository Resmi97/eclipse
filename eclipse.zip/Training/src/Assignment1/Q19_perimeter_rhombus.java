package Assignment1;

public class Q19_perimeter_rhombus {

	public static void main(String[] args) {
		int p,a=4;
		System.out.println("Side:" +a);
		p=4*a;
		System.out.println("Perimeter of the Rhombus:" +p);
	}

}
