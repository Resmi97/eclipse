package Assignment1;

public class Q22_volume_cylinder {

	public static void main(String[] args) {
		double volume,r=3,h=5;
		System.out.println("Base Radius:" +r);
		System.out.println("Height of the cylinder:" +h);
		volume=(3.14*(r*r)*h);
		System.out.println("Volume of the Cylinder:" +volume);
	}

}
