package Assignment1;

public class Q25_csa_cube {

	public static void main(String[] args) {
		int s,a=4;
		System.out.println("Side:" +a);
		s=6*a*a;
		System.out.println("Curved Surface Area of a cube: " +s);
	}

}
