package Assignment1;

public class Q13_equilateral_triangle {

	public static void main(String[] args) {
		double area,side=3;
		System.out.println("Side:" +side);
		area=((Math.sqrt(3)/4)*(side*side));
		System.out.println("Area of the Equilateral Triangle:" +area);
		
	}

}
