package Assignment1;

public class Q5_quadratic {

	public static void main(String[] args) {
		float a=4,b=-2,c=-2,d;
		double root1,root2;
		System.out.println("Quadratic Equation:"+a+"x^2 + "+b+"x + "+c + " = 0");
		d =(b*b)-(4*a*c);
		root1= ((b*-1) +Math.sqrt(d))/(2*a);
		root2= ((b*-1) -Math.sqrt(d))/(2*a);		

		System.out.println("Root 1 = " +root1);
		System.out.println("Root 2 = " +root2);


	}

}
