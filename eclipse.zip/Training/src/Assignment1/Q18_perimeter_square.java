package Assignment1;

public class Q18_perimeter_square {

	public static void main(String[] args) {
		int p,a=4;
		System.out.println("Side:" +a);
		p=4*a;
		System.out.println("Perimeter of the Square:" +p);
	}

}
