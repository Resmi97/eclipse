package Assignment1;

public class Q16_perimeter_parallelogram {

	public static void main(String[] args) {
		int p,a=2,b=4;
		System.out.println("Sides of the parallelogram:" +a +"," +b);
		p=(2*(a+b));
		System.out.println("Perimeter of the parallelogram:" +p);
	}

}
