package Assignment1;

public class Q14_perimeter_circle {

	public static void main(String[] args) {
		double p,r=2;
		System.out.println("Radius:" +r);
		p=3.14*2*r;
		System.out.println("Perimeter of the circle:" +p);
	}

}
