package Assignment1;

public class Q12_rhombus {

	public static void main(String[] args) {
		int p=4,q=2,area;
		System.out.println("Diagonals of the rhombus:" +p +"," +q);
		area=(p*q)/2;
		System.out.println("Area of the Rhombus:" +area);
	}

}
