package Assignment1;

public class Q6_convert {

	public static void main(String[] args) {
		//to Convert Character to String
		char ch ='c';
		String st = Character.toString(ch);
		System.out.println("The string is: " +st);
		
		//char to int
		char abc = '1';
		int a1 = (int)abc;
		System.out.println("The integer is: " + a1);
		
		//int to char
		int bcd = 65;
		char a10 = (char)bcd;
		System.out.println("The character is: " + a10);
		
		//long to int
		long l = 1000045451;
		int l1 = (int)l;
		System.out.println("The integer is: " + l1);
		
		//int to long
		int i=200;  
		long z=i;  
		System.out.println("The long is: " + z); 
		
		//boolean to string
		boolean b1 = true;
		String s1 = Boolean.toString(b1);
		System.out.println("The string is: " + s1);
		
		//string to boolean
		String s2 = "true";
		Boolean b2 = Boolean.valueOf(s2);
		System.out.println("The boolean is: " + b2);
		
		/*to convert string to char
		 String str = "hello";
		char[] ch1 = str.toCharArray();
		System.out.println("The char is: " + tostring(ch1));*/
		
		//string to int
		String s="200";  
		int u=Integer.parseInt(s);  
		System.out.println("The int value is: " + u);  
		
		
		//int to double
		int d2 = 12;
		double d3 = (double)d2;
		System.out.println("The double value is: " + d3);
				
				
		//double to int
		double d = 12.3;
		int d1 = (int)d;
		System.out.println("The integer is: " + d1);
		
		//string to double
		
		//double to string
		
		//primitive types to objects
		
		
		//objects to primitive types


		
		

	}

}
