package Assignment1;

public class Q26_tsa_cylinder {

	public static void main(String[] args) {
		double tsa,r=3,h=5;
		System.out.println("Base Radius:" +r);
		System.out.println("Height of the cylinder:" +h);
		tsa=2*3.14*r*h;
		System.out.println("Total Surface Area of the Cylinder:" +tsa);
	}

}
