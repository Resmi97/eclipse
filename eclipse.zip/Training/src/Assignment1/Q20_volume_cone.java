package Assignment1;

public class Q20_volume_cone {

	public static void main(String[] args) {
		double volume,r=2,h=3;
		System.out.println("Radius:" +r);
		System.out.println("Height:" +h);
		volume=3.14*r*r*h;
		System.out.println("Area of the circle:" +volume);
	}

}
