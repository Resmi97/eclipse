package Assignment1;

public class Q11_parallelogram {

	public static void main(String[] args) {
		double area,b=2,h=3;
		System.out.println("Base:" +b);
		System.out.println("Height:" +h);
		area=b*h;
		System.out.println("Area of the parallelogram:" +area);
	}

}
