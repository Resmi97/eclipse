package Assignment1;

public class Q7_area_circle {

	public static void main(String[] args) {
		double area,r=2;
		System.out.println("Radius:" +r);
		area=3.14*r*r;
		System.out.println("Area of the circle:" +area);

	}

}
