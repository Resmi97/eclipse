package Assignment1;

public class Q29_own_armstrong {

	public static void main(String[] args) {
		int n=371,sum=0,a,t;
		t=n;
		System.out.println("Given number: " +n);
		while(n>0)
		{
			a=n%10;
			sum=sum+(a*a*a);
			n=n/10;
		}
			if(sum==t)
			{
				System.out.println("The given number is an armstrong number");
			}
			else
			{
				System.out.println("The given number is not an armstrong number");
			}
	}

}
