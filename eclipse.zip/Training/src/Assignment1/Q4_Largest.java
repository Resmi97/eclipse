package Assignment1;

public class Q4_Largest {

	public static void main(String[] args) {
		int a=3,b=4,c=5;
		System.out.println("Input numbers:"+a+","+b+","+c);
		if(a>b&&a>c)
			System.out.println("Largest ="+a);
		else if(b>c&&b>a)
			System.out.println("Largest ="+b);
		else
			System.out.println("Largest ="+c);
		
	}

}
