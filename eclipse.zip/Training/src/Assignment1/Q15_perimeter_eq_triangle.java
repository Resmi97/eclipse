package Assignment1;

public class Q15_perimeter_eq_triangle {

	public static void main(String[] args) {
		double p,side=3;
		System.out.println("Side:" +side);
		p=3*side;
		System.out.println("Perimeter of the Equilateral Triangle:" +p);
	}

}
