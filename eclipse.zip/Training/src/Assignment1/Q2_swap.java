package Assignment1;

public class Q2_swap {

	public static void main(String[] args) {
		
		int a=2,b=4,c;
		System.out.println("Before Swap a="+a+" b="+b);
		c=a;
		a=b;
		b=c;
		System.out.println("After Swap a="+a+" b="+b);

	}

}
