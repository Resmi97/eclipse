package Assignment1;

public class Q9_area_rectangle {

	public static void main(String[] args) {
		int l=2,b=3,area;
		System.out.println("Length:" +l);
		System.out.println("Breadth:" +b);
		area=l*b;
		System.out.println("Area of the rectangle:" +area);
	}

}
