package Assignment1;

public class Q27_own_palindrome {

	public static void main(String[] args) {
		int n=646,reverse=0,a,t;
		t=n;
		System.out.println("Given number: " +n);
		while(n>0)
		{
			a=n%10;
			reverse=(reverse*10)+a;
			n=n/10;
		}
			if(reverse==t)
			{
				System.out.println("The given number is a palindrome");
			}
			else
			{
				System.out.println("The given number is not a palindrome");
			}
	}

}
