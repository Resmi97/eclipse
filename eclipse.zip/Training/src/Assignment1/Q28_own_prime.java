package Assignment1;

public class Q28_own_prime {

	public static void main(String[] args) {
		int n=4,flag=0,i;
		System.out.println("Given number: " +n);
		for(i=2;i<=(n/2);++i)
		{
			if(n%i==0)
			{
				flag =1;
			}
			else
			{
				flag = 0;
			}
		}
		
		if(n==1)
		{
			System.out.println("1 is neither prime nor composite");
		}
		else
		{
		if(flag==1)
			{
			System.out.println("The given number is not prime");
			}
		else
			{
			System.out.println("The given number is prime");
			}
		}
	}
		
	}

