package Assignment1;

public class Q24_prism {

	public static void main(String[] args) {
		double volume,a=5,b=4,h=5;
		System.out.println("Altitude:" +a);
		System.out.println("Base:" +b);
		System.out.println("Height:" +h);
		volume=((a*b*h)/2);
		System.out.println("Volume of the prism:" +volume);
	}

}
