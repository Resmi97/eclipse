package Assignment2;
import java.util.Scanner;

public class Conversion18 {

	public static void main(String[] args) {
		
		//double to integer
		Scanner sc=new Scanner(System.in);
				double d = 12.3;
				System.out.println("Enter a double value: " );
				d=sc.nextDouble();
				int d1 = (int)d;

				System.out.println("The integer is: " + d1);
	}

}
