package Assignment2;
import java.util.Scanner;

public class Array12 {

	public static void main(String[] args) {
		//Sum of the elements of the array
		int n,i,sum=0;  
		Scanner sc=new Scanner(System.in);  
		System.out.print("Enter the number of elements you want to store: ");  
		n=sc.nextInt();  
		int[] array = new int[10];  
		System.out.println("Enter the elements of the array: ");  
		for(i=0; i<n; i++)  
		{  
		array[i]=sc.nextInt();  
		}  
		System.out.println("Array elements are: ");  
		for (i=0; i<n; i++)   
		{ 
		System. out. print(array[i] + " ");

		sum=sum+array[i];
		}  
		System.out.println(); 

		System.out.println("Sum of the elements of the array are "+sum);  

	}

}
