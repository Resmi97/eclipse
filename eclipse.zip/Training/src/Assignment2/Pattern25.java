package Assignment2;

import java.util.Scanner;

public class Pattern25 {

	public static void main(String[] args) {
		//Square Star Pattern
		Scanner sc=new Scanner(System.in);
		int i,j,n;
		System.out.println("Enter the number:");
		n=sc.nextInt();
		
		for(i=1;i<=n;i++)
		{
			System.out.print("*");

			for(j=1;j<n;j++)
			{
				System.out.print("*");
			}
			System.out.println();

		}

}

}
