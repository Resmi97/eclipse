
public class Quadratic {

	public static void main(String[] args) {
double a=2;
	}

}
