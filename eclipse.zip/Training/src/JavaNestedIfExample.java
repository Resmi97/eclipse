
public class JavaNestedIfExample {

	public static void main(String[] args) {
		 int age=20;  
		    int weight=80;    
		    //applying condition on age and weight  
		    if(age>=18){    
		        if(weight>50){  
		            System.out.println("You are eligible to donate blood");  
		        }    
		    }

	}

}
