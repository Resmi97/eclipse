
public class AssignmentOperator25a {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		short a=10;  
		short b=10;  
		a=(short)(a+b);//20 which is int now converted to short  
		System.out.println(a);

	}

}
