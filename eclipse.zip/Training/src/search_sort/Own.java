package search_sort;
import java.util.Scanner;  


public class Own {

	public static void main(String[] args) {

		  int size, i, j, temp;  
	       int arr[] = new int[50];  
	       Scanner scan = new Scanner(System.in);  
	         
	       System.out.print("Enter Array Size : ");  
	       size = scan.nextInt();  
	         
	       System.out.print("Enter Array Elements : ");  
	       for(i=0; i<size; i++)  
	       {  
	           arr[i] = scan.nextInt();  
	       }  
	         
	       System.out.print("Sorting Array using Selection Sort Technique\n");  
	       for(i=0; i<size; i++)  
	       {  
	           for(j=i+1; j<size; j++)  
	           {  
	               if(arr[i] > arr[j])  
	               {  
	                   temp = arr[i];  
	                   arr[i] = arr[j];  
	                   arr[j] = temp;  
	               }  
	           }  
	       }  
	         
	       System.out.print("Now the Array after Sorting is :\n");  
	       for(i=0; i<size; i++)  
	       {  
	           System.out.print(arr[i]+ "  ");  
	       }
	       System.out.println("\n\nSearching using Linear Search ");  
	       int item ,flag=0;
	       System.out.println("Enter number to search: ");  
	       item = scan.nextInt();  
	       for(int k = 0; k<10; k++)  
	       {  
	           if(arr[k]==item)  
	           {  
	               flag = k+1;  
	               break;  
	           }  
	           else   
	               flag = 0;   
	       }  
	       if(flag != 0)  
	       {  
	           System.out.println("Item found at location " + flag);  
	       }  
	       else   
	           System.out.println("Item not found");  
	   }  
	}  

