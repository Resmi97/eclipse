package newmaven;

public class Employee {

}
