package java11;

public class CollectionToArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
