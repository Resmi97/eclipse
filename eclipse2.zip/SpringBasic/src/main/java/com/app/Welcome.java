package com.app;

public class Welcome {
	
	private String name;
	private int id;
	
	
	public Welcome(String name,int id) {
		super();
		this.name = name;
		this.id =id;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
public void printName() {
	System.out.println("Welcome to Spring :  "+name);
	System.out.println("Your id is :  "+id);

}
	

}
