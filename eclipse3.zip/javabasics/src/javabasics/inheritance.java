package javabasics;

 class inheritance1 
 	{
	int x=20;
 	}
class child extends inheritance1
	{
	int y=10;
	}
public class inheritance extends child
{
	int z=10;

	public static void main(String[] args)
	{
		inheritance obj = new inheritance();

		System.out.println("value of x is "+obj.x);
		System.out.println("value of y is "+obj.y);
		System.out.println("value of z is "+obj.z);
	}
}

