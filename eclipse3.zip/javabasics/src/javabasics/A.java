package javabasics;
import basics.*;



 class A extends B {

	public static void main(String[] args) {

		A obj = new A();
		obj.msg();
	}

}
