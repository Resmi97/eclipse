package javabasics;

public class basics {

	public static void main(String[] args) {
		int a=10,b=2;
		boolean c=true;
		
		System.out.println(a++); //10 ++
		System.out.println(++a); //11+1 = 12
		System.out.println(b++); //2 ++
		System.out.println(++b); //3+1 = 4
		
		System.out.println(!c); //false
		
		System.out.println(a%b); //12%4
		System.out.println(a/b); //12/4

		int x=2,y=3;
		System.out.println(x<<y); // 2*(2 power 3)
		System.out.println(y>>x); // 3/(2 power 2)
		
		System.out.println(x>1&&y>2); //true
		System.out.println(y<1||x>1); //true

		
	}

}
