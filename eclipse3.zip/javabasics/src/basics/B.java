package basics;

public class B {
protected void msg()
{
	System.out.println("Hello");
}
}
